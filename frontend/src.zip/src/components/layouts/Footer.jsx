import React from 'react'

export default function Footer() {
  return (
    <>
    <footer>
      <p className='text-center'>Food Delivery App. All rights reserved &copy; 2024-2025 by FC </p>
    </footer>
    </>
  )
}
